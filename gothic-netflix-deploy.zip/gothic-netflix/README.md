# Ramzey's Gothic Netflix Vault

Full-stack movie vault with local private collection + public shared catalog.

## Deploy to Railway (no terminal needed)

1. Go to https://railway.app and sign up (GitHub login is easiest)
2. Click **New Project**
3. Choose **Deploy from GitHub repo** (or upload the zip if available)
4. Or: create empty project → add service → upload the gothic-netflix folder
5. Railway will detect the Node.js app and run `npm start`
6. Click the generated public URL (something like https://xxx.up.railway.app)

Anyone who opens that link can:
- See public movies
- Upload new movies
- You can share your local vault into the public section

## Local test (if you have Node)

```bash
cd server
npm install
npm start
```

Open http://localhost:3000

## Notes

- Free tiers have limited storage. Keep videos under ~100-200 MB each.
- Videos are stored on the server disk (ephemeral on free plans — may disappear on redeploy).
- For permanent storage later, connect Cloudflare R2 or S3.
